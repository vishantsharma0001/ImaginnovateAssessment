package com.vishant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImaginnovateApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImaginnovateApplication.class, args);
	}

}
