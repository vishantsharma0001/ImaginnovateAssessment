package com.vishant.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vishant.entity.Employee;
import com.vishant.entity.TaxDeduction;
import com.vishant.repository.EmployeeRepository;

@Service
public class EmployeeService {

	 private final EmployeeRepository employeeRepository;

	    @Autowired
	    public EmployeeService(EmployeeRepository employeeRepository) {
	        this.employeeRepository = employeeRepository;
	    }

	    public Employee createEmployee(Employee employee) {
	        // Perform any additional validation logic here if needed

	        return employeeRepository.save(employee);
	    }
	    
//**************************Calculate Tax Deduction**********************//	    

	    public TaxDeduction calculateTaxDeduction(String employeeId) {
	        Employee employee = employeeRepository.findByEmployeeId(employeeId)
	                .orElseThrow(() -> new IllegalArgumentException("Employee not found"));

	        BigDecimal yearlySalary = calculateYearlySalary(employee);
	        BigDecimal taxAmount = calculateTaxAmount(yearlySalary);
	        BigDecimal cessAmount = calculateCessAmount(yearlySalary);

	        return new TaxDeduction(employee.getEmployeeId(), employee.getFirstName(), employee.getLastName(),
	                yearlySalary, taxAmount, cessAmount);
	    }
	    
//*************************** To Calculate Yearly Salary*******************//	    
	    
	    

	    private BigDecimal calculateYearlySalary(Employee employee) {
	    	 LocalDate currentDate = LocalDate.now();
	    	    LocalDate startOfFinancialYear = currentDate.withMonth(4).withDayOfMonth(1);
	    	    LocalDate endOfFinancialYear = currentDate.withMonth(3).withDayOfMonth(31);

	    	    LocalDate joinDate = employee.getDoj();
	    	    LocalDate effectiveJoinDate = joinDate.isBefore(startOfFinancialYear) ? startOfFinancialYear : joinDate;
	    	    LocalDate effectiveEndDate = currentDate.isBefore(endOfFinancialYear) ? currentDate : endOfFinancialYear;

	    	    long monthsWorked = ChronoUnit.MONTHS.between(effectiveJoinDate, effectiveEndDate) + 1;

	    	    BigDecimal salaryPerMonth = employee.getSalary();
	    	    BigDecimal lossOfPayPerDay = salaryPerMonth.divide(BigDecimal.valueOf(30), 2, RoundingMode.HALF_UP);

	    	    BigDecimal totalSalary = salaryPerMonth.multiply(BigDecimal.valueOf(monthsWorked));
	    	    BigDecimal lossOfPay = lossOfPayPerDay.multiply(BigDecimal.valueOf(effectiveJoinDate.until(effectiveEndDate, ChronoUnit.DAYS)));

	    	    return totalSalary.subtract(lossOfPay);
	    }

	    
//******************************Calculate Tax Amount ************************//
	    
	    private BigDecimal calculateTaxAmount(BigDecimal yearlySalary) {
	    	BigDecimal taxAmount = BigDecimal.ZERO;

	        if (yearlySalary.compareTo(BigDecimal.valueOf(250000)) > 0 && yearlySalary.compareTo(BigDecimal.valueOf(500000)) <= 0) {
	            taxAmount = yearlySalary.subtract(BigDecimal.valueOf(250000)).multiply(BigDecimal.valueOf(0.05));
	        } else if (yearlySalary.compareTo(BigDecimal.valueOf(500000)) > 0 && yearlySalary.compareTo(BigDecimal.valueOf(1000000)) <= 0) {
	            taxAmount = yearlySalary.subtract(BigDecimal.valueOf(500000)).multiply(BigDecimal.valueOf(0.1)).add(BigDecimal.valueOf(25000));
	        } else if (yearlySalary.compareTo(BigDecimal.valueOf(1000000)) > 0) {
	            taxAmount = yearlySalary.subtract(BigDecimal.valueOf(1000000)).multiply(BigDecimal.valueOf(0.2)).add(BigDecimal.valueOf(125000));
	        }

	        return taxAmount;
	    }

	    
//**************************** To Calculate cessAmount*********************//
	    
	    private BigDecimal calculateCessAmount(BigDecimal yearlySalary) {
	    	BigDecimal cessAmount = BigDecimal.ZERO;

	        if (yearlySalary.compareTo(BigDecimal.valueOf(2500000)) > 0) {
	            BigDecimal amountAboveThreshold = yearlySalary.subtract(BigDecimal.valueOf(2500000));
	            cessAmount = amountAboveThreshold.multiply(BigDecimal.valueOf(0.02));
	        }

	        return cessAmount;
	    }

}
