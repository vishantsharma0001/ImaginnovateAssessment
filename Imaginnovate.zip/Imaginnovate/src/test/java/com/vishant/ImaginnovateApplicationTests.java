package com.vishant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImaginnovateApplicationTests {

	@Test
	void contextLoads() {
	}

}
